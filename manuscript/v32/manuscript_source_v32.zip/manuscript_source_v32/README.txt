Article source for Optimization Letters

A Fourth-Power Relative-Error Threshold for Two-Periodic Heavy Ball
Bahadır Yüzbaşı and Mohammad Arashi
Corresponding author: Bahadır Yüzbaşı
Department of Econometrics, İnönü University, Malatya, Türkiye
Department of Statistics, Fırat University, 23199, Elazığ, Türkiye
bahadir.yuzbasi@inonu.edu.tr
ORCID: 0000-0002-6196-3201

Mohammad Arashi
Department of Statistics, Faculty of Mathematical Sciences,
Ferdowsi University of Mashhad, Mashhad, Iran
arashi@um.ac.ir
ORCID: 0000-0002-5881-9241

The main document is main.tex. It contains the complete article, including
three tables, figure captions, references and declarations. The three included
PDF figures are vector graphics with embedded fonts. The bibliography is embedded
in main.tex; no .bib file or external .bbl file is needed.

Compile with an existing current TeX installation:

cd manuscript_source_v32
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex

The unchanged sn-jnl.cls and sn-mathphys-num.bst are supplied. The unchanged
cuted.sty, appendix.sty and wrapfig.sty are included so compilation needs no
paths to the author's research directories. Other dependencies are standard
LaTeX packages. Original copyright and license notices are retained.

The supporting third_party_sources directory contains upstream source and
attribution material for these style files; it is not an article supplement.
Original full distributions are available from:
https://ctan.org/pkg/sttools
https://ctan.org/pkg/appendix
https://ctan.org/pkg/wrapfig
The packages use the LaTeX Project Public License:
https://www.latex-project.org/lppl/

There is a single article, with no separate appendix or Online Resource.

The data and code availability statement links to the public repository.
The companion website is https://byuzbasi.github.io/periodic-momentum/ .
Both authors declare no competing interests.
V32 refines the explicit theorem constants and the corresponding proofs.
The generative AI statement, figures and numerical results are unchanged.
The numerical protocol retains its earlier sufficient constant, denoted
c_kappa^p in the manuscript; it is not retuned to the improved bound.
The numerical sections include GD and quadratically tuned Nesterov comparisons.
The public repository contains synthetic comparisons, the Istanbul code,
configuration, original workbook, accepted records and candidate-selection
documentation. Istanbul is the sole real-data application in this article.
The reported Istanbul F measure is normalized quadratic energy about the
computed QR reference; its residual correction is explicitly documented.
Figure 3 includes a first-16-query inset generated from accepted records.
No new optimization trajectories, QR solves or eigensolves were run.
